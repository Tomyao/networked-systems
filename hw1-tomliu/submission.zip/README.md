# sp18-hw1

UCSD Spring 2018 HW1 starter code

# Student 1
Name: Thomas Liu
PID: A19276714

# Student 2 (optional, if in a group of 2)
Name:
PID:
